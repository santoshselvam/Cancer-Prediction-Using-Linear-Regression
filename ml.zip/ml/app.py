from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load trained Linear Regression model
model = joblib.load("model.pkl")

@app.route("/", methods=["GET", "POST"])
def predict():

    predicted_deaths = None
    year = None

    if request.method == "POST":

        year = int(request.form["year"])

        features = np.array([[year]])

        predicted_deaths = model.predict(features)[0]

    return render_template(
        "forms.html",
        predicted_deaths=predicted_deaths,
        year=year
    )

if __name__ == "__main__":
    app.run(debug=True)